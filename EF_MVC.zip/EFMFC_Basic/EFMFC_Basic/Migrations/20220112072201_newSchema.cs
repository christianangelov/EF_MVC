﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EFMFC_Basic.Migrations
{
    public partial class newSchema : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
